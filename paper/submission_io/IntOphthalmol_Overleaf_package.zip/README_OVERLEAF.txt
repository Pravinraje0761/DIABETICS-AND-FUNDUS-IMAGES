Overleaf package - International Ophthalmology submission
Manuscript: Retinal foundation-model versus ImageNet pretraining for diabetic retinopathy grading across datasets

How to compile on Overleaf
1. Overleaf -> New Project -> Upload Project -> select this ZIP.
2. Menu -> Compiler: pdfLaTeX. Main document: main.tex.
3. Recompile. The Springer Nature class (sn-jnl.cls) and basic reference style (sn-basic.bst)
   are included, so no template download is needed.

Files
main.tex            manuscript (Springer Nature template, sn-basic, numbered citations)
references.bib      bibliography (biomedical entries verified against PubMed, 6 Nov 2026)
main.bbl            pre-built bibliography (some submission systems require it)
Fig1-Fig5.pdf       vector figures used by main.tex (600-dpi TIFF copies are in the submission folder)
sn-jnl.cls, sn-basic.bst   Springer Nature LaTeX template files
