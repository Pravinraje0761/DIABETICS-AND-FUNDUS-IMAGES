Online Resource 3 - International Ophthalmology
Article: Retinal foundation-model versus ImageNet pretraining for diabetic retinopathy grading across datasets: how much of the external performance drop reflects the reference standard?
Author: Pravin Raj E, Independent Researcher, Chennai, Tamil Nadu, India. Corresponding author: epravinraj0761@gmail.com

Contents (CSV, UTF-8)
predictions/<model>__<dataset>_preds.csv
  One row per image: id_code, y_true (reference grade 0-4), y_pred (argmax grade),
  prob_0..prob_4 (softmax probabilities), entropy (predictive entropy, nats).
  Models: baseline_efficientnet_b3, baseline_resnet50, retfound_linprobe, retfound_full,
  baseline_efficientnet_b3_labelsmoothing (control). Datasets: APTOS-internal (n=733),
  Messidor-2 (n=1,744), IDRiD (official release, n=516; test-set IDs suffixed "test").
splits/aptos_{train,val,test}.csv  APTOS 2019 image IDs and grades for each split (seed 42).
audit/idrid_mirror_vs_official_labels.csv  Official IDRiD grade vs third-party mirror grade per image.
audit/saliency_localization_per_image.csv  Per-image localisation metrics against IDRiD lesion masks.
Images are not redistributed; obtain them from the original releases (see Data availability).
